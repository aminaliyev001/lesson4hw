﻿using System.Text.Json.Serialization;

namespace WpfApp5.Cars;
public class Car
{
    public Car() { }
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("car_brand")]
    public string Car_Brand { get; set; }

    [JsonPropertyName("car_model")]
    public string Car_Model { get; set; }

    [JsonPropertyName("car_color")]
    public string Car_Color { get; set; }

    [JsonPropertyName("year")]
    public int Year { get; set; }

    [JsonPropertyName("price")]
    public string Price { get; set; }

    [JsonPropertyName("availability")]
    public bool Availability { get; set; }

    [JsonPropertyName("car_vin")]
    public string Vin { get; set; }
}
