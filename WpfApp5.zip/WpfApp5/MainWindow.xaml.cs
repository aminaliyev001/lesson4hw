﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.Json;
using System.IO;
using WpfApp5.Cars;
using System.Diagnostics;

namespace WpfApp5
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        Stopwatch _stopwatch = new Stopwatch();
        CancellationTokenSource _cts = new CancellationTokenSource();
        ObservableCollection<Car> _cars = new ObservableCollection<Car>();
        public ObservableCollection<Car> Cars
        {
            get { return _cars; }
            set
            {
                _cars = value;
                OnPropertyChanged(nameof(Cars));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }
        public void loadcarsfromfile()
        {
            string file1 = null;

            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            Thread thread = new Thread(() =>
            {
                _stopwatch.Restart();
                Application.Current.Dispatcher.Invoke(() =>
                {
                    Cars.Clear();
                });
                for (int i = 0; i < 5; i++)
                {
                    token.ThrowIfCancellationRequested();
                    file1 = i + 1 + ".json";
                    string jsonContent = File.ReadAllText("Cars/" + file1);
                    var cars = JsonSerializer.Deserialize<List<Car>>(jsonContent);
                    foreach (var car in cars)
                    {
                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            Cars.Add(car);
                        });
                    }
                }
                _stopwatch.Stop();
                Application.Current.Dispatcher.Invoke(() =>
                {
                    time.Content = _stopwatch.Elapsed.TotalSeconds;
                });
            });
            thread.Start();
        }
        public void loadcarsfromfile2()
        {
            string file1 = null;

            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            _stopwatch.Restart();
            Application.Current.Dispatcher.Invoke(() =>
            {
                Cars.Clear();
            });
            for (int i = 0; i < 5; i++)
            {
                file1 = i + 1 + ".json";
                Thread thread = new Thread(() =>
                {
                    token.ThrowIfCancellationRequested();
                    string jsonContent = File.ReadAllText("Cars/" + file1);
                    var cars = JsonSerializer.Deserialize<List<Car>>(jsonContent);
                    foreach (var car in cars)
                    {
                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            Cars.Add(car);
                        });
                    }
                });
                thread.Start();
            }
            _stopwatch.Stop();
            Application.Current.Dispatcher.Invoke(() =>
            {
                time.Content = _stopwatch.Elapsed.TotalSeconds;
            });
        }
        public void CancelLoading()
        {
            if (_cts != null)
                _cts.Cancel();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var selected = combox.SelectedItem as ComboBoxItem;
            var item = selected.Content.ToString();
            if (selected == null)
            {
                MessageBox.Show("Combobox bos qala bilmez");
                return;
            }
            if(item == "Single")
            {
                loadcarsfromfile();

            } else
            {
                loadcarsfromfile2();
            }
        }

        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            CancelLoading();
        }
    }
}